from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash
from models import db


class AppSetting(db.Model):
    __tablename__ = 'app_settings'

    key = db.Column(db.String(80), primary_key=True)
    value_hash = db.Column(db.String(255), nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    @classmethod
    def set_common_password(cls, password):
        setting = cls.query.get('common_company_password')
        if setting is None:
            setting = cls(key='common_company_password', value_hash='')
            db.session.add(setting)
        setting.value_hash = generate_password_hash(password)
        return setting

    @classmethod
    def check_common_password(cls, password):
        setting = cls.query.get('common_company_password')
        return bool(setting and check_password_hash(setting.value_hash, password))

    @classmethod
    def has_common_password(cls):
        return cls.query.get('common_company_password') is not None
