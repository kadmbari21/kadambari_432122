from datetime import datetime
import secrets
from werkzeug.security import generate_password_hash, check_password_hash
from models import db

class PasswordResetOTP(db.Model):
    __tablename__ = 'password_reset_otps'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=True, index=True)
    email = db.Column(db.String(120), nullable=False, index=True)
    otp_hash = db.Column(db.String(255), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    expires_at = db.Column(db.DateTime, nullable=False)
    attempts = db.Column(db.Integer, default=0, nullable=False)
    verified = db.Column(db.Boolean, default=False, nullable=False)
    used = db.Column(db.Boolean, default=False, nullable=False)

    @staticmethod
    def generate_otp_code():
        """Generates a cryptographically secure 6-digit numeric OTP string."""
        return f"{secrets.randbelow(900000) + 100000:06d}"

    def set_otp(self, otp_code):
        self.otp_hash = generate_password_hash(str(otp_code).strip())

    def check_otp(self, otp_code):
        if not self.otp_hash:
            return False
        return check_password_hash(self.otp_hash, str(otp_code).strip())

    def is_expired(self):
        return datetime.utcnow() > self.expires_at

    def __repr__(self):
        return f'<PasswordResetOTP id={self.id} email={self.email} verified={self.verified} used={self.used}>'
