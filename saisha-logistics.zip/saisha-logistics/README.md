# SAISHA LOGISTICS
## Smart Logistics Billing & Invoice Management System

A production-grade full-stack billing and transport operations management web application built for **Saisha Logistics (Fleet Owners & Transport Contractors)**.

---

## 🚀 Key Features

1. **Authentication & Security**
   - Secure Flask session-based authentication with `werkzeug.security` password hashing (`scrypt`).
   - Protected routes with `@login_required` decorators.
   - Show/Hide password toggle on login screen.
   - Default administrator account: `admin` / `admin123`.

2. **Live Dynamic Dashboard**
   - Real-time statistics fetched directly from the database:
     - Total Clients
     - Total Invoices
     - Pending Invoices
     - Pending Amount (₹)
     - Paid Invoices
     - Paid Amount (₹)
   - Recent invoices ledger with color-coded status badges (`Paid`, `Pending`, `Partially Paid`).

3. **Client Master (Full CRUD)**
   - Complete consignor / consignee registry: Client Name, Address, Mobile, Email, GSTIN, PAN.
   - Input validation: Required fields, 10-digit mobile number, standard 15-character GSTIN regex.
   - Duplicate prevention on both Name and GSTIN.
   - Dynamic auto-population into Create Invoice screen.

4. **Create Invoice & Real-Time Calculation Engine**
   - Auto-generated sequential invoice numbers: `SL/001/26-27`, `SL/002/26-27`, etc. based on Indian Financial Year.
   - Transport details: Origin, Destination, Vehicle No, Container No, Vehicle Type, Weight, Movement Date, Bill Date, Department.
   - Itemized charges: Freight Rate, Container Loading, Weight Charges, Parking Charges, Detention Charges, Less: Advance Received.
   - Formula:
     $$\text{Total Charges} = \text{Rate} + \text{Loading} + \text{Weight Charges} + \text{Parking} + \text{Detention}$$
     $$\text{Gross Total} = \text{Total Charges} - \text{Advance}$$
   - Synchronized calculation: Client-side for instant preview + Server-side single source of truth.
   - Indian currency representation in words (e.g. *Fifteen Thousand Three Hundred Thirty-Six Rupees Only*).

5. **Invoice Preview & Vector ReportLab PDF**
   - High-fidelity A4 printable sheet matching official company layout.
   - Embeds official Saisha Logistics logo with aspect ratio preserved.
   - Includes PAN, Banking details (HDFC Bank, Kalamboli), dynamic UPI QR code, and Authorized Signatory box.
   - Downloadable vector A4 PDF via `GET /invoices/<id>/pdf` named `SAISHA_INVOICE_SL_001_26-27.pdf`.

6. **Invoice History & Filter System**
   - Search by Invoice Number, Client Name, Vehicle No, or Route.
   - Filters by Client, Payment Status, and Date Range.
   - Pagination support.
   - Actions: View Preview, Download PDF, Edit, Delete.

7. **Payment Update & Ledger**
   - Track partial and full settlements.
   - Automatically recalculates $\text{Pending Amount} = \text{Gross Total} - \text{Paid Amount}$.
   - Auto-updates invoice status: `Pending` ➔ `Partially Paid` ➔ `Paid`.
   - Complete transaction audit trail.

8. **Excel Report Export**
   - Exports complete invoice ledger to `SAISHA_INVOICE_REPORT.xlsx` using `openpyxl`.
   - Formatted table headers, auto-adjusted column widths, INR currency formatting, and dynamic `SUM()` formula totals.

---

## 🛠️ Technology Stack

- **Backend**: Python 3.11, Flask
- **ORM & Database**: SQLAlchemy, SQLite (with MySQL migration readiness)
- **PDF Generation**: ReportLab
- **Excel Generation**: openpyxl
- **Frontend**: HTML5, Vanilla CSS3, JavaScript, Bootstrap 5, Font Awesome 6
- **Typography**: Inter (Google Fonts)

---

## 🏃 Running the Application

1. Open PowerShell or Terminal in the project directory:
   ```powershell
   cd "C:\Users\AK_43.locked\.gemini\antigravity-ide\scratch\saisha_logistics"
   ```

2. Run the application using Python:
   ```powershell
   & "C:\Users\AK_43.locked\AppData\Local\Programs\Python311\python.exe" app.py
   ```

3. Open your browser and navigate to:
   ```
   http://127.0.0.1:5000
   ```

4. Sign in with the default credentials:
   - **Username**: `admin`
   - **Password**: `admin123`

---

## 🔄 Migrating from SQLite to MySQL

The database layer is built using SQLAlchemy ORM. To switch from SQLite to MySQL, update the `DATABASE_URL` environment variable or edit `config.py`:

```python
# In config.py:
SQLALCHEMY_DATABASE_URI = os.environ.get(
    'DATABASE_URL',
    'mysql+pymysql://username:password@localhost:3306/saisha_logistics'
)
```
Install the MySQL driver:
```bash
pip install pymysql cryptography
```
The application will automatically initialize the tables upon startup!
