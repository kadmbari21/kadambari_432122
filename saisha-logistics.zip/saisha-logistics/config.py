import os
import re
import urllib.parse
from dotenv import load_dotenv

BASE_DIR = os.path.abspath(os.path.dirname(__file__))

# Load environment variables from .env file if available
load_dotenv(os.path.join(BASE_DIR, '.env'))

def normalize_database_url(url):
    """
    Robustly standardizes database URIs for SQLAlchemy + psycopg2:
    - Strips UI placeholder brackets like [YOUR-PASSWORD]
    - URL-encodes special characters (such as @ in passwords)
    - Replaces deprecated postgres:// or postgresql:// with postgresql+psycopg2://
    """
    if not url:
        return url
    url = url.strip().strip('"\'')
    
    # 1. Bracketed password case: postgresql://user:[pwd]@host:port/db
    m_bracket = re.match(r'^(postgresql(?:\+[a-zA-Z0-9_]+)?|postgres)://([^:]+):\[(.*?)\]@([^/]+)/(.+)$', url)
    if m_bracket:
        scheme, user, raw_pwd, host_port, dbname = m_bracket.groups()
        unquoted = urllib.parse.unquote(raw_pwd)
        encoded_pwd = urllib.parse.quote(unquoted, safe='')
        return f"postgresql+psycopg2://{user}:{encoded_pwd}@{host_port}/{dbname}"
        
    # 2. General case: find scheme and split user:pwd from host:port/db via rightmost '@'
    m = re.match(r'^(postgresql(?:\+[a-zA-Z0-9_]+)?|postgres)://(.+)$', url)
    if m:
        scheme, rest = m.groups()
        at_idx = rest.rfind('@')
        if at_idx != -1 and '/' in rest[at_idx:]:
            auth_part = rest[:at_idx]
            host_db = rest[at_idx + 1:]
            if ':' in auth_part:
                user, raw_pwd = auth_part.split(':', 1)
                if raw_pwd.startswith('[') and raw_pwd.endswith(']'):
                    raw_pwd = raw_pwd[1:-1]
                unquoted = urllib.parse.unquote(raw_pwd)
                encoded_pwd = urllib.parse.quote(unquoted, safe='')
                return f"postgresql+psycopg2://{user}:{encoded_pwd}@{host_db}"

    if url.startswith('postgres://'):
        url = url.replace('postgres://', 'postgresql+psycopg2://', 1)
    elif url.startswith('postgresql://'):
        url = url.replace('postgresql://', 'postgresql+psycopg2://', 1)
    return url

# Serverless platforms (Vercel, AWS Lambda) mount the app read-only; only /tmp is writable.
IS_SERVERLESS = bool(os.environ.get('VERCEL') or os.environ.get('AWS_LAMBDA_FUNCTION_NAME'))
WRITABLE_DIR = '/tmp/saisha' if IS_SERVERLESS else BASE_DIR
BUNDLED_SQLITE_PATH = os.path.join(BASE_DIR, 'database', 'saisha_logistics.db')

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY', 'saisha-logistics-super-secret-key-2026')
    
    # Database Configuration: Supabase (PostgreSQL) or fallback to local SQLite
    _db_url = normalize_database_url(os.environ.get('DATABASE_URL'))
    if _db_url:
        SQLALCHEMY_DATABASE_URI = _db_url
        SQLALCHEMY_ENGINE_OPTIONS = {
            'pool_pre_ping': True,
            'pool_recycle': 180,
            'pool_timeout': 30,
            'max_overflow': 10,
            'connect_args': {
                'keepalives': 1,
                'keepalives_idle': 30,
                'keepalives_interval': 10,
                'keepalives_count': 5,
            }
        }
    else:
        # Local SQLite fallback (ephemeral copy under /tmp when serverless)
        SQLITE_PATH = os.path.join(WRITABLE_DIR, 'database', 'saisha_logistics.db')
        SQLALCHEMY_DATABASE_URI = f"sqlite:///{SQLITE_PATH}"
        SQLALCHEMY_ENGINE_OPTIONS = {
            'pool_pre_ping': True,
        }
        
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    
    # Directories
    GENERATED_INVOICES_DIR = os.path.join(WRITABLE_DIR, 'generated_invoices')
    EXPORTS_DIR = os.path.join(WRITABLE_DIR, 'exports')
    STATIC_DIR = os.path.join(BASE_DIR, 'static')
    
    # Company Brand Details
    COMPANY_NAME = "SAISHA LOGISTICS"
    COMPANY_TAGLINE = "FLEET OWNERS & TRANSPORT CONTRACTORS"
    COMPANY_ADDRESS = "LIG - II / G - 13 Sector 2-E, Kalamboli, Navi Mumbai - 410218."
    COMPANY_PHONES = "9529923242 / 9865646156"
    COMPANY_EMAIL = "saishalogistics2026@gmail.com"
    COMPANY_PAN = "BYTPCS273P"
    
    # Banking details
    BANK_NAME = "HDFC BANK"
    BANK_BRANCH = "KALAMBOLI"
    BANK_ACCOUNT_NO = "50200110750392"
    BANK_IFSC = "HDFC0002822"
