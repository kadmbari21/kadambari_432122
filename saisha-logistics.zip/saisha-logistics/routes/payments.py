from datetime import datetime, date
from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify, session
from models import db, Invoice, Payment, User
from routes.auth import login_required
from routes.invoices import parse_date_input

payments_bp = Blueprint('payments', __name__)

@payments_bp.route('/payments')
@login_required
def index():
    user_id = session.get('user_id')
    current_user = User.query.get(user_id)
    is_admin = bool(current_user and current_user.role == 'admin')

    status_filter = request.args.get('status', 'All')
    search = request.args.get('search', '').strip()
    filter_user_id = request.args.get('user_id', '').strip()
    
    if is_admin:
        query = Invoice.query.options(db.joinedload(Invoice.user), db.joinedload(Invoice.client))
        if filter_user_id and filter_user_id.isdigit():
            query = query.filter(Invoice.user_id == int(filter_user_id))
        recent_payments = Payment.query.order_by(Payment.payment_date.desc(), Payment.id.desc()).limit(15).all()
    else:
        query = Invoice.query.filter_by(user_id=user_id).options(db.joinedload(Invoice.client))
        recent_payments = Payment.query.filter_by(user_id=user_id).order_by(Payment.payment_date.desc(), Payment.id.desc()).limit(15).all()
    
    if status_filter and status_filter != 'All':
        query = query.filter(Invoice.payment_status == status_filter)
        
    if search:
        query = query.filter(
            (Invoice.invoice_no.ilike(f'%{search}%')) |
            (Invoice.vehicle_no.ilike(f'%{search}%'))
        )
        
    invoices = query.order_by(Invoice.bill_date.desc(), Invoice.id.desc()).all()
    
    return render_template(
        'payment_update.html',
        invoices=invoices,
        recent_payments=recent_payments,
        status_filter=status_filter,
        search=search,
        is_admin=is_admin,
        today_str=date.today().strftime('%Y-%m-%d')
    )

@payments_bp.route('/payments/add', methods=['POST'])
@login_required
def add():
    user_id = session.get('user_id')
    current_user = User.query.get(user_id)
    is_admin = bool(current_user and current_user.role == 'admin')

    invoice_id = request.form.get('invoice_id')
    amount_raw = request.form.get('amount')
    payment_date_raw = request.form.get('payment_date')
    payment_mode = request.form.get('payment_mode', 'Bank Transfer')
    reference_no = request.form.get('reference_no', '').strip()
    notes = request.form.get('notes', '').strip()
    next_url = request.form.get('next') or request.referrer
    
    if not invoice_id:
        flash('Invoice ID is required.', 'danger')
        return redirect(next_url or url_for('payments.index'))
        
    if is_admin:
        invoice = Invoice.query.filter_by(id=int(invoice_id)).first_or_404()
    else:
        invoice = Invoice.query.filter_by(id=int(invoice_id), user_id=user_id).first_or_404()
    
    try:
        amount = float(amount_raw or 0.0)
    except ValueError:
        flash('Invalid payment amount.', 'danger')
        return redirect(next_url or url_for('payments.index'))
        
    if amount <= 0:
        flash('Payment amount must be greater than zero.', 'danger')
        return redirect(next_url or url_for('payments.index'))
        
    payment_date = parse_date_input(payment_date_raw, date.today())
        
    # Check if amount exceeds live pending balance
    current_pending = invoice.pending_balance
    if amount > current_pending + 0.01:
        flash(f'Notice: Entered installment (₹{amount:,.2f}) exceeds current pending balance (₹{current_pending:,.2f}).', 'warning')
        
    payment = Payment(
        user_id=invoice.user_id,
        invoice_id=invoice.id,
        amount=amount,
        payment_date=payment_date,
        payment_mode=payment_mode,
        reference_no=reference_no,
        notes=notes
    )
    try:
        db.session.add(payment)
        db.session.flush()
        
        # Recalculate dynamic invoice settlement balance from all payments
        invoice.calculate_totals()
        db.session.commit()
        
        flash(f'Installment payment of ₹{amount:,.2f} recorded for Invoice {invoice.invoice_no}. Remaining pending balance: ₹{invoice.pending_balance:,.2f}. Status: {invoice.payment_status}', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error recording payment: {e}', 'danger')
    return redirect(next_url or url_for('invoices.preview', id=invoice.id))

@payments_bp.route('/payments/<int:id>/delete', methods=['POST'])
@login_required
def delete(id):
    user_id = session.get('user_id')
    current_user = User.query.get(user_id)
    is_admin = bool(current_user and current_user.role == 'admin')
    
    if is_admin:
        payment = Payment.query.filter_by(id=id).first_or_404()
    else:
        payment = Payment.query.filter_by(id=id, user_id=user_id).first_or_404()
        
    invoice = payment.invoice
    inv_no = invoice.invoice_no if invoice else ''
    amt = payment.amount
    
    db.session.delete(payment)
    db.session.flush()
    if invoice:
        invoice.calculate_totals()
    db.session.commit()
    
    flash(f'Payment installment of ₹{amt:,.2f} deleted. Invoice {inv_no} balance updated to ₹{invoice.pending_balance if invoice else 0:,.2f}.', 'success')
    next_url = request.form.get('next') or request.referrer or url_for('payments.index')
    return redirect(next_url)

@payments_bp.route('/api/payments/record', methods=['POST'])
@login_required
def record_api():
    user_id = session.get('user_id')
    current_user = User.query.get(user_id)
    is_admin = bool(current_user and current_user.role == 'admin')

    data = request.get_json() or {}
    invoice_id = data.get('invoice_id')
    amount = float(data.get('amount', 0))
    payment_mode = data.get('payment_mode', 'Bank Transfer')
    reference_no = data.get('reference_no', '')
    notes = data.get('notes', '')
    payment_date_raw = data.get('payment_date')
    payment_date = parse_date_input(payment_date_raw, date.today())
    
    if not invoice_id or amount <= 0:
        return jsonify({'error': 'Invalid invoice ID or amount'}), 400
        
    if is_admin:
        invoice = Invoice.query.filter_by(id=int(invoice_id)).first_or_404()
    else:
        invoice = Invoice.query.filter_by(id=int(invoice_id), user_id=user_id).first_or_404()
    
    payment = Payment(
        user_id=invoice.user_id,
        invoice_id=invoice.id,
        amount=amount,
        payment_date=payment_date,
        payment_mode=payment_mode,
        reference_no=reference_no,
        notes=notes
    )
    db.session.add(payment)
    db.session.flush()
    invoice.calculate_totals()
    db.session.commit()
    
    return jsonify({
        'success': True,
        'message': f'Installment of ₹{amount:,.2f} recorded.',
        'invoice': invoice.to_dict(),
        'payment': payment.to_dict(),
        'breakdown': invoice.get_payment_breakdown()
    })
