import re
from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify, session
from models import db, Client, Invoice
from routes.auth import login_required

clients_bp = Blueprint('clients', __name__)

def validate_gst(gst_str):
    if not gst_str:
        return True # Optional field
    gst_str = gst_str.strip().upper()
    # Standard 15-character GSTIN regex: 2 digits (state) + 5 chars (PAN) + 4 digits (PAN) + 1 char (PAN) + 1 char + 1 char + 1 char
    pattern = r"^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$"
    return bool(re.match(pattern, gst_str))

def validate_mobile(mobile_str):
    if not mobile_str:
        return False, "", "Mobile number is required."
    # Clean non-digits
    digits = re.sub(r'[^0-9]', '', str(mobile_str).strip())
    # Strip leading India country code 91 if full international format provided (12 digits)
    if len(digits) == 12 and digits.startswith('91'):
        digits = digits[2:]
    elif len(digits) == 11 and digits.startswith('0'):
        digits = digits[1:]

    if len(digits) < 10:
        return False, digits, f"Client contact number must be exactly 10 digits. Entered {len(digits)} digit{'s' if len(digits) != 1 else ''}."
    elif len(digits) > 10:
        return False, digits, f"Client contact number cannot exceed 10 digits. Entered {len(digits)} digits."
    return True, digits, ""

@clients_bp.route('/clients')
@login_required
def index():
    user_id = session['user_id']
    clients = Client.query.filter_by(user_id=user_id).order_by(Client.name.asc()).all()
    return render_template('clients.html', clients=clients)

@clients_bp.route('/clients/add', methods=['POST'])
@login_required
def add():
    user_id = session['user_id']
    name = request.form.get('name', '').strip()
    address = request.form.get('address', '').strip()
    mobile = request.form.get('mobile', '').strip()
    email = request.form.get('email', '').strip()
    gst_number = request.form.get('gst_number', '').strip().upper()
    pan_number = request.form.get('pan_number', '').strip().upper()
    
    # Required fields validation
    if not name or not address or not mobile:
        flash('Client Name, Address, and Mobile Number are required.', 'danger')
        return redirect(url_for('clients.index'))
        
    is_valid_mobile, clean_mobile, mobile_err = validate_mobile(mobile)
    if not is_valid_mobile:
        flash(mobile_err, 'danger')
        return redirect(url_for('clients.index'))
        
    if gst_number and not validate_gst(gst_number):
        flash('Invalid GSTIN format. Please enter a valid 15-character GSTIN.', 'danger')
        return redirect(url_for('clients.index'))
        
    # Duplicate check: check if same name or same GST already exists for THIS user
    existing = Client.query.filter(
        Client.user_id == user_id,
        (Client.name.ilike(name)) | 
        ((Client.gst_number != '') & (Client.gst_number == gst_number))
    ).first()
    
    if existing:
        flash(f'A client with this name or GST number already exists: "{existing.name}".', 'warning')
        return redirect(url_for('clients.index'))
        
    # Auto-extract PAN from GST if PAN is not provided
    if not pan_number and gst_number and len(gst_number) == 15:
        pan_number = gst_number[2:12]
        
    formatted_mobile = f"+91 {clean_mobile}"
    client = Client(
        user_id=user_id,
        name=name,
        address=address,
        mobile=formatted_mobile,
        email=email,
        gst_number=gst_number,
        pan_number=pan_number
    )
    try:
        db.session.add(client)
        db.session.commit()
        flash(f'Client "{name}" added successfully!', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error adding client: {e}', 'danger')
    return redirect(url_for('clients.index'))

@clients_bp.route('/clients/edit/<int:id>', methods=['POST'])
@login_required
def edit(id):
    user_id = session['user_id']
    client = Client.query.filter_by(id=id, user_id=user_id).first_or_404()
    
    name = request.form.get('name', '').strip()
    address = request.form.get('address', '').strip()
    mobile = request.form.get('mobile', '').strip()
    email = request.form.get('email', '').strip()
    gst_number = request.form.get('gst_number', '').strip().upper()
    pan_number = request.form.get('pan_number', '').strip().upper()
    
    if not name or not address or not mobile:
        flash('Client Name, Address, and Mobile Number are required.', 'danger')
        return redirect(url_for('clients.index'))
        
    is_valid_mobile, clean_mobile, mobile_err = validate_mobile(mobile)
    if not is_valid_mobile:
        flash(mobile_err, 'danger')
        return redirect(url_for('clients.index'))
        
    if gst_number and not validate_gst(gst_number):
        flash('Invalid GSTIN format. Please enter a valid 15-character GSTIN.', 'danger')
        return redirect(url_for('clients.index'))
        
    # Check duplicate on another client record for THIS user
    existing = Client.query.filter(
        Client.user_id == user_id,
        Client.id != id,
        ((Client.name.ilike(name)) | ((Client.gst_number != '') & (Client.gst_number == gst_number)))
    ).first()
    if existing:
        flash(f'Another client with this name or GSTIN already exists ({existing.name}).', 'warning')
        return redirect(url_for('clients.index'))
        
    formatted_mobile = f"+91 {clean_mobile}"
    client.name = name
    client.address = address
    client.mobile = formatted_mobile
    client.email = email
    client.gst_number = gst_number
    client.pan_number = pan_number or (gst_number[2:12] if gst_number and len(gst_number) == 15 else '')
    
    try:
        db.session.commit()
        flash(f'Client "{client.name}" updated successfully!', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error updating client: {e}', 'danger')
    return redirect(url_for('clients.index'))

@clients_bp.route('/clients/delete/<int:id>', methods=['POST'])
@login_required
def delete(id):
    user_id = session['user_id']
    client = Client.query.filter_by(id=id, user_id=user_id).first_or_404()
    # Check if client has active invoices for this user
    invoice_count = Invoice.query.filter_by(client_id=id, user_id=user_id).count()
    if invoice_count > 0:
        flash(f'Cannot delete client "{client.name}" because {invoice_count} invoice(s) are linked to them.', 'danger')
        return redirect(url_for('clients.index'))
        
    name = client.name
    try:
        db.session.delete(client)
        db.session.commit()
        flash(f'Client "{name}" deleted successfully.', 'info')
    except Exception as e:
        db.session.rollback()
        flash(f'Error deleting client: {e}', 'danger')
    return redirect(url_for('clients.index'))

@clients_bp.route('/api/clients/<int:id>')
@login_required
def get_client(id):
    user_id = session['user_id']
    client = Client.query.filter_by(id=id, user_id=user_id).first_or_404()
    return jsonify(client.to_dict())

@clients_bp.route('/api/clients')
@login_required
def list_clients():
    user_id = session['user_id']
    clients = Client.query.filter_by(user_id=user_id).order_by(Client.name.asc()).all()
    return jsonify([c.to_dict() for c in clients])
