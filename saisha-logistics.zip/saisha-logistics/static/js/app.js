document.addEventListener('DOMContentLoaded', function() {
    // 1. Sidebar Toggle Behavior
    const sidebarCollapseBtn = document.getElementById('sidebarCollapse');
    const sidebar = document.getElementById('sidebar');
    const content = document.getElementById('content');
    const backdrop = document.getElementById('sidebarBackdrop');

    function closeMobileSidebar() {
        if (sidebar && sidebar.classList.contains('active')) {
            sidebar.classList.remove('active');
            if (backdrop) backdrop.classList.remove('show');
        }
    }

    if (sidebarCollapseBtn && sidebar) {
        sidebarCollapseBtn.addEventListener('click', function(e) {
            e.stopPropagation();
            if (window.innerWidth >= 992) {
                sidebar.classList.toggle('collapsed');
                if (content) {
                    content.classList.toggle('expanded');
                }
            } else {
                sidebar.classList.toggle('active');
                if (backdrop) {
                    if (sidebar.classList.contains('active')) {
                        backdrop.classList.add('show');
                    } else {
                        backdrop.classList.remove('show');
                    }
                }
            }
        });
    }

    if (backdrop) {
        backdrop.addEventListener('click', closeMobileSidebar);
    }

    window.addEventListener('resize', function() {
        if (window.innerWidth >= 992) {
            closeMobileSidebar();
        }
    });

    // 2. Password Visibility Toggle on Login Page
    const togglePasswordBtn = document.getElementById('togglePassword');
    const passwordInput = document.getElementById('password');
    const toggleIcon = document.getElementById('toggleIcon');

    if (togglePasswordBtn && passwordInput && toggleIcon) {
        togglePasswordBtn.addEventListener('click', function() {
            const isPassword = passwordInput.getAttribute('type') === 'password';
            passwordInput.setAttribute('type', isPassword ? 'text' : 'password');
            toggleIcon.classList.toggle('fa-eye');
            toggleIcon.classList.toggle('fa-eye-slash');
        });
    }

    // 3. Auto-dismiss flash alerts after 5 seconds
    const alerts = document.querySelectorAll('.alert-dismissible');
    alerts.forEach(function(alert) {
        setTimeout(function() {
            const bsAlert = bootstrap.Alert.getOrCreateInstance(alert);
            if (bsAlert) {
                bsAlert.close();
            }
        }, 5000);
    });

    // 4. Prevent mouse wheel from unintentionally incrementing/decrementing number inputs
    document.addEventListener('wheel', function(e) {
        if (document.activeElement && (document.activeElement.type === 'number' || document.activeElement.classList.contains('calc-input'))) {
            document.activeElement.blur();
        }
    }, { passive: true });
});

