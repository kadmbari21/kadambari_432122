"""
Optional: Migrate local SQLite data to Supabase PostgreSQL.
Run this script AFTER setting your DATABASE_URL in .env if you wish to transfer
any clients, invoices, and payments created locally in SQLite into Supabase.
"""
import os
import sys
import sqlite3
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

from app import create_app, seed_database
from models import db, User, Client, Invoice, InvoiceItem, Payment

def migrate():
    app = create_app()
    with app.app_context():
        db_uri = app.config['SQLALCHEMY_DATABASE_URI']
        if 'sqlite' in db_uri.lower():
            print("[ERROR] DATABASE_URL in .env is not pointing to Supabase/PostgreSQL.")
            print("Please set your Supabase DATABASE_URL in .env first.")
            return

        sqlite_path = os.path.join(app.root_path, 'database', 'saisha_logistics.db')
        if not os.path.exists(sqlite_path):
            print(f"[ERROR] Local SQLite database not found at: {sqlite_path}")
            return

        print(f"Connecting to local SQLite: {sqlite_path}")
        con = sqlite3.connect(sqlite_path)
        cur = con.cursor()

        print("Ensuring Supabase schema exists...")
        seed_database(app)

        # 1. Migrate Clients
        cur.execute("SELECT id, name, address, mobile, email, gst_number, pan_number FROM clients")
        sqlite_clients = cur.fetchall()
        print(f"\nFound {len(sqlite_clients)} client(s) in local SQLite.")
        for row in sqlite_clients:
            c_id, name, address, mobile, email, gst, pan = row
            existing = Client.query.filter_by(name=name).first()
            if not existing:
                client = Client(
                    id=c_id,
                    name=name,
                    address=address,
                    mobile=mobile,
                    email=email,
                    gst_number=gst,
                    pan_number=pan
                )
                db.session.add(client)
                print(f"  + Added Client: {name}")
        db.session.commit()

        # 2. Migrate Invoices
        cur.execute("""
            SELECT id, invoice_no, client_id, bill_date, movement_date, from_location, to_location,
                   vehicle_no, container_no, vehicle_type, department, weight, rate, advance,
                   container_loading_charges, weight_charges, parking_charges, detention_charges,
                   detention_description, total_charges, gross_total, paid_amount, pending_amount,
                   payment_status, notes
            FROM invoices
        """)
        sqlite_invoices = cur.fetchall()
        print(f"\nFound {len(sqlite_invoices)} invoice(s) in local SQLite.")
        for row in sqlite_invoices:
            inv_no = row[1]
            existing = Invoice.query.filter_by(invoice_no=inv_no).first()
            if not existing:
                from datetime import datetime
                b_date = datetime.strptime(row[3], '%Y-%m-%d').date() if row[3] else None
                m_date = datetime.strptime(row[4], '%Y-%m-%d').date() if row[4] else None
                
                inv = Invoice(
                    id=row[0],
                    invoice_no=inv_no,
                    client_id=row[2],
                    bill_date=b_date,
                    movement_date=m_date,
                    from_location=row[5],
                    to_location=row[6],
                    vehicle_no=row[7],
                    container_no=row[8],
                    vehicle_type=row[9],
                    department=row[10],
                    weight=row[11],
                    rate=row[12],
                    advance=row[13],
                    container_loading_charges=row[14],
                    weight_charges=row[15],
                    parking_charges=row[16],
                    detention_charges=row[17],
                    detention_description=row[18],
                    total_charges=row[19],
                    gross_total=row[20],
                    paid_amount=row[21],
                    pending_amount=row[22],
                    payment_status=row[23],
                    notes=row[24]
                )
                db.session.add(inv)
                print(f"  + Added Invoice: {inv_no}")
        db.session.commit()

        # 3. Migrate Invoice Items
        cur.execute("SELECT id, invoice_id, item_date, particulars, quantity, rate, advance, amount FROM invoice_items")
        sqlite_items = cur.fetchall()
        for row in sqlite_items:
            existing_item = InvoiceItem.query.filter_by(id=row[0]).first()
            if not existing_item:
                from datetime import datetime
                i_date = datetime.strptime(row[2], '%Y-%m-%d').date() if row[2] else None
                item = InvoiceItem(
                    id=row[0],
                    invoice_id=row[1],
                    item_date=i_date,
                    particulars=row[3],
                    quantity=row[4],
                    rate=row[5],
                    advance=row[6],
                    amount=row[7]
                )
                db.session.add(item)
        db.session.commit()

        con.close()
        print("\n[SUCCESS] Local data successfully migrated to Supabase!")

if __name__ == '__main__':
    migrate()
