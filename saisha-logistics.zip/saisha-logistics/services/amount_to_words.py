"""
Indian numbering system currency to words converter.
e.g. 15,336 -> Fifteen Thousand Three Hundred Thirty Six Rupees Only
"""

def number_to_words_inr(number):
    try:
        num = float(number)
    except (ValueError, TypeError):
        return "Zero Rupees Only"
        
    if num == 0:
        return "Zero Rupees Only"
        
    # Split rupees and paise
    parts = f"{num:.2f}".split('.')
    rupees = int(parts[0])
    paise = int(parts[1])
    
    ones = ["", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine",
            "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen",
            "Seventeen", "Eighteen", "Nineteen"]
    tens = ["", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"]

    def convert_two_digits(n):
        if n < 20:
            return ones[n]
        else:
            return (tens[n // 10] + (" " + ones[n % 10] if n % 10 != 0 else "")).strip()

    def convert_three_digits(n):
        hundreds = n // 100
        remainder = n % 100
        res = ""
        if hundreds > 0:
            res += ones[hundreds] + " Hundred"
            if remainder > 0:
                res += " and "
        if remainder > 0:
            res += convert_two_digits(remainder)
        return res.strip()

    # Indian System: Crore (1,00,00,000), Lakh (1,00,000), Thousand (1,000), Hundred (100)
    words = []
    
    crores = rupees // 10000000
    rupees %= 10000000
    
    lakhs = rupees // 100000
    rupees %= 100000
    
    thousands = rupees // 1000
    rupees %= 1000
    
    hundreds_part = rupees
    
    if crores > 0:
        words.append(convert_two_digits(crores) + " Crore")
    if lakhs > 0:
        words.append(convert_two_digits(lakhs) + " Lakh")
    if thousands > 0:
        words.append(convert_two_digits(thousands) + " Thousand")
    if hundreds_part > 0:
        words.append(convert_three_digits(hundreds_part))
        
    rupees_str = " ".join(words).strip()
    if not rupees_str:
        rupees_str = "Zero"
        
    result = rupees_str + " Rupees"
    
    if paise > 0:
        result += " and " + convert_two_digits(paise) + " Paise"
        
    result += " Only"
    return result
