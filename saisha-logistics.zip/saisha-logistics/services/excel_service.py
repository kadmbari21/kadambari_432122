import io
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

def generate_invoices_excel(invoices, output_path=None):
    """
    Generates a professional styled Excel report of invoices using openpyxl.
    """
    wb = Workbook()
    ws = wb.active
    ws.title = "Invoice Register"
    
    # Page title header
    ws.merge_cells("A1:K1")
    title_cell = ws["A1"]
    title_cell.value = "SAISHA LOGISTICS - INVOICE REGISTER & PAYMENT SUMMARY"
    title_cell.font = Font(name="Calibri", size=14, bold=True, color="FFFFFF")
    title_cell.fill = PatternFill(start_color="1E293B", end_color="1E293B", fill_type="solid")
    title_cell.alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[1].height = 32

    # Column headers
    headers = [
        "Invoice No.",
        "Bill Date",
        "Client Name",
        "From",
        "To",
        "Vehicle No.",
        "Container No.",
        "Gross Total (₹)",
        "Paid Amount (₹)",
        "Pending Amount (₹)",
        "Payment Status"
    ]
    
    ws.append([]) # Row 2 empty
    ws.append(headers) # Row 3 headers
    ws.row_dimensions[3].height = 24

    header_font = Font(name="Calibri", size=11, bold=True, color="FFFFFF")
    header_fill = PatternFill(start_color="C62828", end_color="C62828", fill_type="solid")
    center_align = Alignment(horizontal="center", vertical="center")
    right_align = Alignment(horizontal="right", vertical="center")
    left_align = Alignment(horizontal="left", vertical="center")
    
    thin_border = Border(
        left=Side(style='thin', color='CBD5E1'),
        right=Side(style='thin', color='CBD5E1'),
        top=Side(style='thin', color='CBD5E1'),
        bottom=Side(style='thin', color='CBD5E1')
    )

    for col_idx in range(1, len(headers) + 1):
        cell = ws.cell(row=3, column=col_idx)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = center_align
        cell.border = thin_border

    start_row = 4
    current_row = start_row

    status_colors = {
        'Paid': 'DCFCE7',       # Soft green
        'Pending': 'FEE2E2',    # Soft red
        'Partially Paid': 'FEF3C7' # Soft yellow
    }

    for inv in invoices:
        bill_date_str = inv.bill_date.strftime("%d-%m-%Y") if inv.bill_date else ""
        client_name = inv.client.name if inv.client else "N/A"
        
        row_data = [
            inv.invoice_no,
            bill_date_str,
            client_name,
            inv.from_location or "",
            inv.to_location or "",
            inv.vehicle_no or "",
            inv.container_no or "",
            float(inv.gross_total or 0.0),
            float(inv.paid_amount or 0.0),
            float(inv.pending_amount or 0.0),
            inv.payment_status or "Pending"
        ]
        ws.append(row_data)
        
        # Style data row
        ws.cell(row=current_row, column=1).alignment = center_align
        ws.cell(row=current_row, column=2).alignment = center_align
        ws.cell(row=current_row, column=3).alignment = left_align
        ws.cell(row=current_row, column=4).alignment = left_align
        ws.cell(row=current_row, column=5).alignment = left_align
        ws.cell(row=current_row, column=6).alignment = center_align
        ws.cell(row=current_row, column=7).alignment = center_align
        
        # Numeric currency columns
        for c in [8, 9, 10]:
            num_cell = ws.cell(row=current_row, column=c)
            num_cell.number_format = '₹ #,##0.00'
            num_cell.alignment = right_align

        # Status badge
        status_cell = ws.cell(row=current_row, column=11)
        status_cell.alignment = center_align
        color_hex = status_colors.get(inv.payment_status, 'F1F5F9')
        status_cell.fill = PatternFill(start_color=color_hex, end_color=color_hex, fill_type="solid")
        status_cell.font = Font(name="Calibri", size=10, bold=True)

        for col_idx in range(1, len(headers) + 1):
            ws.cell(row=current_row, column=col_idx).border = thin_border
            
        ws.row_dimensions[current_row].height = 20
        current_row += 1

    # Totals Row
    if len(invoices) > 0:
        ws.merge_cells(start_row=current_row, start_column=1, end_row=current_row, end_column=7)
        total_label = ws.cell(row=current_row, column=1)
        total_label.value = "TOTALS"
        total_label.font = Font(name="Calibri", size=11, bold=True)
        total_label.alignment = Alignment(horizontal="right", vertical="center")
        
        # Sum Formulas
        ws.cell(row=current_row, column=8).value = f"=SUM(H{start_row}:H{current_row-1})"
        ws.cell(row=current_row, column=9).value = f"=SUM(I{start_row}:I{current_row-1})"
        ws.cell(row=current_row, column=10).value = f"=SUM(J{start_row}:J{current_row-1})"
        
        total_fill = PatternFill(start_color="E2E8F0", end_color="E2E8F0", fill_type="solid")
        for col_idx in range(1, len(headers) + 1):
            c_cell = ws.cell(row=current_row, column=col_idx)
            c_cell.font = Font(name="Calibri", size=11, bold=True)
            c_cell.fill = total_fill
            c_cell.border = thin_border
            if col_idx in [8, 9, 10]:
                c_cell.number_format = '₹ #,##0.00'
                c_cell.alignment = right_align
        ws.row_dimensions[current_row].height = 22

    # Auto-fit column widths
    for col in ws.columns:
        max_len = 0
        col_letter = get_column_letter(col[0].column)
        for cell in col:
            # Skip title row from calculation
            if cell.row == 1:
                continue
            val_str = str(cell.value or '')
            if len(val_str) > max_len:
                max_len = len(val_str)
        ws.column_dimensions[col_letter].width = max(max_len + 4, 12)

    # Freeze header row
    ws.freeze_panes = "A4"

    if output_path is not None:
        wb.save(output_path)
        return output_path
    else:
        stream = io.BytesIO()
        wb.save(stream)
        stream.seek(0)
        return stream
