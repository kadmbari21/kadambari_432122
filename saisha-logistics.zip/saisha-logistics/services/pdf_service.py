import os
import io
from PIL import Image as PILImage
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, Image as RLImage
from services.amount_to_words import number_to_words_inr

def draw_a4_page_decorations(c, doc):
    """
    Draws the full-width red bottom footer banner across the A4 sheet.
    Matches the official executive invoice design.
    """
    c.saveState()
    # Bottom Red Banner across entire width (0 to 595.28 points)
    c.setFillColor(colors.HexColor('#C62828'))
    c.rect(0, 0, 595.2756, 22, fill=1, stroke=0)
    
    # White centered text inside the bottom banner
    c.setFillColor(colors.white)
    c.setFont('Helvetica-Bold', 7.5)
    c.drawCentredString(595.2756 / 2, 7.5, "SAISHA LOGISTICS  |  LIG - II / G - 13 Sector 2-E, Kalamboli, Navi Mumbai - 410218  |  9529923242 / 9665646156")
    c.restoreState()

def format_currency_val(val):
    """
    Format numeric values cleanly without .00 for whole numbers.
    Guarantees that if there is no value, 0 is returned.
    """
    if val is None or val == '' or val == '-' or val == 0:
        return '0'
    try:
        f = float(val)
        if f == 0:
            return '0'
        if f.is_integer():
            return f"{int(f):,}"
        return f"{f:,.2f}"
    except (ValueError, TypeError):
        return '0'

def generate_invoice_pdf(invoice, output_path=None):
    """
    Generates a true, professional A4 print-ready PDF invoice for Saisha Logistics.
    Includes dedicated payment details & QR code section after gross total.
    Strictly guaranteed 1 single page with zero spillover.
    """
    buffer = io.BytesIO() if output_path is None else output_path
    
    # Standard ISO A4 dimensions (210mm x 297mm | 595.28 x 841.89 points)
    left_m = 20
    right_m = 20
    top_m = 16
    bottom_m = 26 # room for bottom red banner
    printable_width = 595.2756 - (left_m + right_m) # 555.28 points
    
    doc = SimpleDocTemplate(
        buffer,
        pagesize=A4,
        leftMargin=left_m,
        rightMargin=right_m,
        topMargin=top_m,
        bottomMargin=bottom_m,
        title=f"Tax Invoice {invoice.invoice_no} - Saisha Logistics",
        author="Saisha Logistics",
        subject=f"Tax Invoice {invoice.invoice_no}"
    )
    
    styles = getSampleStyleSheet()
    
    normal_style = styles['Normal']
    normal_style.fontSize = 8
    normal_style.leading = 10.5
    normal_style.textColor = colors.HexColor('#1E293B')
    
    bold_style = ParagraphStyle('BoldStyle', parent=normal_style, fontName='Helvetica-Bold')
    small_style = ParagraphStyle('SmallStyle', parent=normal_style, fontSize=7, leading=9)
    
    company_title_style = ParagraphStyle(
        'CompanyTitle', parent=styles['Normal'],
        fontName='Helvetica-Bold', fontSize=20, leading=22,
        textColor=colors.HexColor('#C62828'), alignment=1
    )
    company_tagline_style = ParagraphStyle(
        'CompanyTagline', parent=styles['Normal'],
        fontName='Helvetica-Bold', fontSize=9.5, leading=11.5,
        textColor=colors.HexColor('#0F172A'), alignment=1
    )
    company_address_style = ParagraphStyle(
        'CompanyAddress', parent=styles['Normal'],
        fontSize=7.5, leading=9.5, textColor=colors.HexColor('#334155'), alignment=1
    )
    contact_style = ParagraphStyle(
        'CompanyContact', parent=styles['Normal'],
        fontSize=7.5, leading=9.5, textColor=colors.HexColor('#C62828'), alignment=1
    )

    top_story = []
    
    # 1. Header with Official Logo & Company Name
    logo_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'static', 'images', 'saisha_logo.png')
    logo_element = None
    if os.path.exists(logo_path):
        try:
            logo_element = RLImage(logo_path, width=96, height=52)
        except Exception:
            logo_element = Paragraph("<b>SAISHA LOGISTICS</b>", bold_style)
    else:
        logo_element = Paragraph("<b>SAISHA LOGISTICS</b>", bold_style)
    
    header_text_cell = [
        Paragraph("SAISHA LOGISTICS", company_title_style),
        Spacer(1, 1.5),
        Paragraph("FLEET OWNERS &amp; TRANSPORT CONTRACTORS", company_tagline_style),
        Spacer(1, 1.5),
        Paragraph("LIG - II / G - 13 Sector 2-E, Kalamboli, Navi Mumbai - 410218", company_address_style),
        Spacer(1, 1.5),
        Paragraph("<b>Mobile No :</b> 9529923242 / 9665646156 &nbsp;&nbsp;&nbsp;&nbsp; <u>saishalogistics2026@gmail.com</u>", contact_style)
    ]
    header_table = Table([[logo_element, header_text_cell]], colWidths=[105, printable_width - 105])
    header_table.setStyle(TableStyle([
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
        ('ALIGN', (0,0), (0,0), 'CENTER'),
        ('BOTTOMPADDING', (0,0), (-1,-1), 1),
        ('TOPPADDING', (0,0), (-1,-1), 0),
    ]))
    top_story.append(header_table)
    top_story.append(Spacer(1, 4))

    # Red horizontal accent line below header
    red_line = Table([['']], colWidths=[printable_width], rowHeights=[2])
    red_line.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), colors.HexColor('#C62828')),
        ('TOPPADDING', (0,0), (-1,-1), 0),
        ('BOTTOMPADDING', (0,0), (-1,-1), 0),
    ]))
    top_story.append(red_line)
    top_story.append(Spacer(1, 5))

    # 2. Party & Invoice Info (Bill To on Left, Invoice Details in Box on Right)
    client_name = invoice.client.name if invoice.client else 'ABC Transport'
    client_addr = (invoice.client.address if invoice.client else '') or '-'
    client_mob = (invoice.client.mobile if invoice.client else '') or '-'
    client_gst = (invoice.client.gst_number if invoice.client else '') or '-'
    bill_date_str = invoice.bill_date.strftime('%d.%m.%Y') if invoice.bill_date else ''
    m_date_str = invoice.movement_date.strftime('%d.%m.%Y') if invoice.movement_date else bill_date_str
    
    left_info = [
        Paragraph("<b>BILL TO:</b>", ParagraphStyle('BillToLabel', parent=bold_style, fontSize=8, textColor=colors.HexColor('#C62828'))),
        Spacer(1, 1),
        Paragraph(f"<b>M/S. {client_name}</b>", ParagraphStyle('ClName', parent=bold_style, fontSize=9, leading=11, textColor=colors.HexColor('#0F172A'))),
        Paragraph(f"{client_addr}", normal_style),
        Paragraph(f"<b>MOB :</b> {client_mob}", normal_style),
        Paragraph(f"<b>GSTIN :</b> {client_gst}", normal_style),
        Paragraph("<b>A/C :</b> -", normal_style)
    ]
    
    status_text = invoice.payment_status or 'Pending'
    status_color = '#C62828' if status_text.lower() == 'pending' else ('#16A34A' if status_text.lower() == 'paid' else '#D97706')
    
    # Creator info formatted in solid black font
    if invoice.user:
        if invoice.user.full_name and invoice.user.username and invoice.user.full_name != invoice.user.username:
            creator_name = f"{invoice.user.full_name} ({invoice.user.username})"
        else:
            creator_name = invoice.user.username or invoice.user.full_name or "Admin"
    else:
        creator_name = "Administrator (admin)"

    right_info = [
        Paragraph(f"<b>INVOICE NO : <font color='#C62828'>{invoice.invoice_no}</font></b>", ParagraphStyle('InvNo', parent=bold_style, fontSize=9.5, leading=12)),
        Spacer(1, 4),
        Paragraph(f"<b>Invoice Date :</b> {bill_date_str}", normal_style),
        Spacer(1, 3),
        Paragraph(f"<b>Status :</b> <font color='{status_color}'><b>{status_text}</b></font>", normal_style),
        Spacer(1, 3),
        Paragraph(f"<b>Created By :</b> <font color='#000000'><b>{creator_name}</b></font>", normal_style)
    ]
    
    party_table = Table([[left_info, right_info]], colWidths=[printable_width * 0.58, printable_width * 0.42])
    party_table.setStyle(TableStyle([
        ('BOX', (0,0), (-1,-1), 0.75, colors.HexColor('#CBD5E1')),
        ('BACKGROUND', (1,0), (1,0), colors.HexColor('#F8FAFC')),
        ('LINEBEFORE', (1,0), (1,0), 0.75, colors.HexColor('#CBD5E1')),
        ('TOPPADDING', (0,0), (-1,-1), 5),
        ('BOTTOMPADDING', (0,0), (-1,-1), 5),
        ('LEFTPADDING', (0,0), (-1,-1), 8),
        ('RIGHTPADDING', (0,0), (-1,-1), 8),
        ('VALIGN', (0,0), (-1,-1), 'TOP'),
    ]))
    top_story.append(party_table)
    top_story.append(Spacer(1, 5))

    # 3. Transport Details (Header Banner + 4-Column Grid)
    load_weight_parts = []
    if invoice.vehicle_type:
        load_weight_parts.append(invoice.vehicle_type)
    if invoice.weight:
        load_weight_parts.append(invoice.weight)
    load_weight_str = ' / '.join(load_weight_parts) if load_weight_parts else '-'
    
    via_route = 'Direct'
    if hasattr(invoice, 'stops') and invoice.stops:
        via_route = ', '.join([s.location for s in invoice.stops])
    elif invoice.department:
        via_route = invoice.department

    trans_banner = Paragraph("<b>TRANSPORT DETAILS</b>", ParagraphStyle('TransBan', parent=bold_style, fontSize=8, textColor=colors.HexColor('#1E293B')))
    
    trans_data = [
        [trans_banner, "", "", ""],
        [
            Paragraph("<b>Transport Mode :</b>", normal_style),
            Paragraph(f"{invoice.transport_mode or 'Road'}", normal_style),
            Paragraph("<b>Movement Date :</b>", normal_style),
            Paragraph(f"{m_date_str}", normal_style)
        ],
        [
            Paragraph("<b>From :</b>", normal_style),
            Paragraph(f"{invoice.from_location}", normal_style),
            Paragraph("<b>Vehicle No :</b>", normal_style),
            Paragraph(f"<b>{invoice.vehicle_no}</b>", bold_style)
        ],
        [
            Paragraph("<b>Via :</b>", normal_style),
            Paragraph(f"{via_route}", normal_style),
            Paragraph("<b>Container No :</b>", normal_style),
            Paragraph(f"{invoice.container_no or '-'}", normal_style)
        ],
        [
            Paragraph("<b>To :</b>", normal_style),
            Paragraph(f"{invoice.to_location}", normal_style),
            Paragraph("<b>Load / Weight :</b>", normal_style),
            Paragraph(f"{load_weight_str}", normal_style)
        ]
    ]
    
    col_w_label = 95
    col_w_val = (printable_width - (col_w_label * 2)) / 2
    trans_table = Table(trans_data, colWidths=[col_w_label, col_w_val, col_w_label, col_w_val])
    trans_table.setStyle(TableStyle([
        ('SPAN', (0,0), (-1,0)),
        ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#E2E8F0')),
        ('BOX', (0,0), (-1,-1), 0.75, colors.HexColor('#CBD5E1')),
        ('INNERGRID', (0,1), (-1,-1), 0.5, colors.HexColor('#E2E8F0')),
        ('LINEBELOW', (0,0), (-1,0), 0.75, colors.HexColor('#CBD5E1')),
        ('TOPPADDING', (0,0), (-1,-1), 3),
        ('BOTTOMPADDING', (0,0), (-1,-1), 3),
        ('LEFTPADDING', (0,0), (-1,-1), 6),
        ('RIGHTPADDING', (0,0), (-1,-1), 6),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
    ]))
    top_story.append(trans_table)
    top_story.append(Spacer(1, 5))

    # 4. Charges & Particulars Table (Exactly 5 Columns: Sr, Particulars, Rate, Advance, Amount)
    headers = [
        Paragraph("<b>Sr.</b>", ParagraphStyle('ThSr', parent=bold_style, fontSize=7.5, alignment=1)),
        Paragraph("<b>Particulars / Description of Charges</b>", ParagraphStyle('ThDesc', parent=bold_style, fontSize=7.5)),
        Paragraph("<b>Rate (Rs.)</b>", ParagraphStyle('ThRate', parent=bold_style, fontSize=7.5, alignment=2)),
        Paragraph("<b>Advance (Rs.)</b>", ParagraphStyle('ThAdv', parent=bold_style, fontSize=7.5, alignment=2)),
        Paragraph("<b>Amount (Rs.)</b>", ParagraphStyle('ThAmt', parent=bold_style, fontSize=7.5, alignment=2)),
    ]
    
    col_widths = [26, printable_width - 256, 75, 75, 80]

    rows = [headers]
    sr = 1

    # Calculations: Mathematical single source of truth
    rate = float(invoice.rate or 0.0)
    advance = float(invoice.advance or 0.0)
    loading = float(invoice.loading_charges or invoice.container_loading_charges or 0.0)
    unloading = float(invoice.unloading_charges or 0.0)
    parking = float(invoice.parking_charges or 0.0)
    detention = float(invoice.detention_charges or 0.0)
    varahi = float(invoice.varahi_charges or 0.0)
    weight_charges = float(invoice.weight_charges or 0.0)
    
    # Line 1: Freight / Transportation Charges
    rows.append([
        Paragraph(str(sr), ParagraphStyle('SrCell', parent=normal_style, alignment=1)),
        Paragraph("<b>Freight / Transportation Charges</b>", bold_style),
        Paragraph(format_currency_val(rate), ParagraphStyle('RCell', parent=normal_style, alignment=2)),
        Paragraph(format_currency_val(advance), ParagraphStyle('ACell', parent=normal_style, alignment=2)),
        Paragraph(f"<b>{format_currency_val(rate)}</b>", ParagraphStyle('MCell', parent=bold_style, alignment=2))
    ])
    sr += 1
    
    # Additional charges only when > 0 (Show 0 if no advance)
    if loading > 0:
        rows.append([
            Paragraph(str(sr), ParagraphStyle('SrCell', parent=normal_style, alignment=1)),
            Paragraph("Container Loading Charges", normal_style),
            Paragraph(format_currency_val(loading), ParagraphStyle('RCell', parent=normal_style, alignment=2)),
            Paragraph("0", ParagraphStyle('ACell', parent=normal_style, alignment=2)),
            Paragraph(format_currency_val(loading), ParagraphStyle('MCell', parent=normal_style, alignment=2))
        ])
        sr += 1
        
    if unloading > 0:
        rows.append([
            Paragraph(str(sr), ParagraphStyle('SrCell', parent=normal_style, alignment=1)),
            Paragraph("Unloading Charges", normal_style),
            Paragraph(format_currency_val(unloading), ParagraphStyle('RCell', parent=normal_style, alignment=2)),
            Paragraph("0", ParagraphStyle('ACell', parent=normal_style, alignment=2)),
            Paragraph(format_currency_val(unloading), ParagraphStyle('MCell', parent=normal_style, alignment=2))
        ])
        sr += 1
        
    if parking > 0:
        rows.append([
            Paragraph(str(sr), ParagraphStyle('SrCell', parent=normal_style, alignment=1)),
            Paragraph("Parking Charges", normal_style),
            Paragraph(format_currency_val(parking), ParagraphStyle('RCell', parent=normal_style, alignment=2)),
            Paragraph("0", ParagraphStyle('ACell', parent=normal_style, alignment=2)),
            Paragraph(format_currency_val(parking), ParagraphStyle('MCell', parent=normal_style, alignment=2))
        ])
        sr += 1
        
    if detention > 0:
        d_lbl = "Detention Charges"
        if invoice.detention_days:
            d_days_str = str(invoice.detention_days)
            if 'day' not in d_days_str.lower():
                d_days_str += f" Day{'s' if d_days_str != '1' else ''}"
            d_lbl += f" ({d_days_str})"
        elif invoice.detention_description:
            d_lbl += f" ({invoice.detention_description})"
            
        rows.append([
            Paragraph(str(sr), ParagraphStyle('SrCell', parent=normal_style, alignment=1)),
            Paragraph(d_lbl, normal_style),
            Paragraph(format_currency_val(detention), ParagraphStyle('RCell', parent=normal_style, alignment=2)),
            Paragraph("0", ParagraphStyle('ACell', parent=normal_style, alignment=2)),
            Paragraph(format_currency_val(detention), ParagraphStyle('MCell', parent=normal_style, alignment=2))
        ])
        sr += 1
        
    if varahi > 0:
        rows.append([
            Paragraph(str(sr), ParagraphStyle('SrCell', parent=normal_style, alignment=1)),
            Paragraph("Varahi Charges", normal_style),
            Paragraph(format_currency_val(varahi), ParagraphStyle('RCell', parent=normal_style, alignment=2)),
            Paragraph("0", ParagraphStyle('ACell', parent=normal_style, alignment=2)),
            Paragraph(format_currency_val(varahi), ParagraphStyle('MCell', parent=normal_style, alignment=2))
        ])
        sr += 1
        
    if weight_charges > 0:
        rows.append([
            Paragraph(str(sr), ParagraphStyle('SrCell', parent=normal_style, alignment=1)),
            Paragraph("Weight Charges", normal_style),
            Paragraph(format_currency_val(weight_charges), ParagraphStyle('RCell', parent=normal_style, alignment=2)),
            Paragraph("0", ParagraphStyle('ACell', parent=normal_style, alignment=2)),
            Paragraph(format_currency_val(weight_charges), ParagraphStyle('MCell', parent=normal_style, alignment=2))
        ])
        sr += 1

    # Exact calculated totals
    total_charges = round(rate + loading + unloading + parking + detention + varahi + weight_charges, 2)
    gross_total = round(total_charges - advance, 2)

    # Totals rows at the bottom of the charges table
    total_charges_row = [
        "", Paragraph("<b>Total</b>", ParagraphStyle('TotLbl', parent=bold_style, fontSize=8, alignment=2)), "", "",
        Paragraph(f"<b>{format_currency_val(total_charges)}</b>", ParagraphStyle('TotVal', parent=bold_style, fontSize=8, alignment=2))
    ]
    advance_row = [
        "", Paragraph("<b>Less : Advance</b>", ParagraphStyle('AdvLbl', parent=normal_style, fontSize=8, alignment=2)), "", "",
        Paragraph(format_currency_val(advance), ParagraphStyle('AdvVal', parent=normal_style, fontSize=8, alignment=2))
    ]
    gross_total_row = [
        "", Paragraph("<b>Gross Total Payable</b>", ParagraphStyle('GrossLbl', parent=bold_style, fontSize=8.5, alignment=2, textColor=colors.HexColor('#C62828'))), "", "",
        Paragraph(f"<b><font color='#C62828'>{format_currency_val(gross_total)}</font></b>", ParagraphStyle('GrossVal', parent=bold_style, fontSize=8.5, alignment=2))
    ]
    
    rows.append(total_charges_row)
    rows.append(advance_row)
    rows.append(gross_total_row)
    
    totals_start_idx = len(rows) - 3
    gross_total_idx = len(rows) - 1
    
    table = Table(rows, colWidths=col_widths)
    t_style = [
        ('BOX', (0,0), (-1,-1), 0.75, colors.HexColor('#1E293B')),
        ('INNERGRID', (0,0), (-1, totals_start_idx - 1), 0.5, colors.HexColor('#E2E8F0')),
        ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#F1F5F9')),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
        ('TOPPADDING', (0,0), (-1,-1), 3),
        ('BOTTOMPADDING', (0,0), (-1,-1), 3),
        ('LEFTPADDING', (0,0), (-1,-1), 5),
        ('RIGHTPADDING', (0,0), (-1,-1), 5),
        
        # Totals spanning across columns 1 to 3
        ('SPAN', (1, totals_start_idx), (3, totals_start_idx)),
        ('SPAN', (1, totals_start_idx + 1), (3, totals_start_idx + 1)),
        ('SPAN', (1, totals_start_idx + 2), (3, totals_start_idx + 2)),
        
        ('LINEABOVE', (0, totals_start_idx), (-1, totals_start_idx), 0.75, colors.HexColor('#CBD5E1')),
        ('LINEABOVE', (0, gross_total_idx), (-1, gross_total_idx), 1, colors.HexColor('#C62828')),
        ('LINEBELOW', (0, gross_total_idx), (-1, gross_total_idx), 1, colors.HexColor('#C62828')),
        ('BOX', (0, gross_total_idx), (-1, gross_total_idx), 1, colors.HexColor('#C62828')),
        ('BACKGROUND', (0, gross_total_idx), (-1, gross_total_idx), colors.HexColor('#FEF2F2')),
    ]
    table.setStyle(TableStyle(t_style))
    top_story.append(table)
    top_story.append(Spacer(1, 4))
    
    # 5. PAN and Amount in Words Box (Directly after Gross Total)
    pan_text = "<b>PAN NO :-</b> BYTPCS273P &nbsp;&nbsp;|&nbsp;&nbsp; <b>GST Category :</b> Goods Transport Agency (GTA)"
    amount_in_words = number_to_words_inr(gross_total)
    
    words_data = [
        [Paragraph(pan_text, bold_style)],
        [Paragraph(f"<b>Amount In Words :</b> {amount_in_words}", normal_style)]
    ]
    words_table = Table(words_data, colWidths=[printable_width])
    words_table.setStyle(TableStyle([
        ('BOX', (0,0), (-1,-1), 0.75, colors.HexColor('#CBD5E1')),
        ('TOPPADDING', (0,0), (-1,-1), 3),
        ('BOTTOMPADDING', (0,0), (-1,-1), 3),
        ('LEFTPADDING', (0,0), (-1,-1), 6),
        ('BACKGROUND', (0,0), (-1,-1), colors.HexColor('#F8FAFC')),
    ]))
    top_story.append(words_table)

    # 6. Single Dedicated Individual Section: Payment Details & UPI QR Code
    bank_label_style = ParagraphStyle('BankLbl', parent=normal_style, fontSize=7, leading=8.5, textColor=colors.HexColor('#334155'), fontName='Helvetica-Bold')
    bank_val_style = ParagraphStyle('BankVal', parent=normal_style, fontSize=7, leading=8.5, textColor=colors.HexColor('#0F172A'))
    
    bank_data = [
        [Paragraph("Bank Name", bank_label_style), Paragraph("<b>HDFC BANK</b>", bank_val_style)],
        [Paragraph("Branch Name", bank_label_style), Paragraph("KALAMBOLI", bank_val_style)],
        [Paragraph("Account No", bank_label_style), Paragraph("<b>50200110750392</b>", bank_val_style)],
        [Paragraph("IFSC Code", bank_label_style), Paragraph("<b>HDFC0002822</b>", bank_val_style)],
    ]
    bank_inner_table = Table(bank_data, colWidths=[58, 96])
    bank_inner_table.setStyle(TableStyle([
        ('BOX', (0,0), (-1,-1), 0.5, colors.HexColor('#CBD5E1')),
        ('INNERGRID', (0,0), (-1,-1), 0.5, colors.HexColor('#CBD5E1')),
        ('BACKGROUND', (0,0), (0,-1), colors.HexColor('#F8FAFC')),
        ('TOPPADDING', (0,0), (-1,-1), 2),
        ('BOTTOMPADDING', (0,0), (-1,-1), 2),
        ('LEFTPADDING', (0,0), (-1,-1), 3.5),
        ('RIGHTPADDING', (0,0), (-1,-1), 3.5),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
    ]))
    
    total_bill_amt = float(getattr(invoice, 'total_bill_amount', 0.0) or (gross_total if gross_total > 0 else getattr(invoice, 'total_charges', 0.0)))
    total_paid_amt = float(getattr(invoice, 'total_paid_amount', 0.0) or getattr(invoice, 'paid_amount', 0.0) or 0.0)
    pending_amt = float(getattr(invoice, 'pending_balance', 0.0) or getattr(invoice, 'pending_amount', 0.0) or max(0.0, total_bill_amt - total_paid_amt))
    status_val = invoice.payment_status or 'Pending'
            
    total_bill_val = format_currency_val(total_bill_amt)
    paid_val = format_currency_val(total_paid_amt)
    pending_val = format_currency_val(pending_amt)
    status_color = '#C62828' if status_val.lower() == 'pending' else ('#16A34A' if status_val.lower() == 'paid' else '#D97706')
    
    payment_summary_cell = [
        Paragraph(f"<b>Payment Status :</b> <font color='{status_color}'><b>{status_val}</b></font>", normal_style),
        Spacer(1, 1.5),
        Paragraph(f"<b>Created By :</b> <font color='#000000'><b>{creator_name}</b></font>", normal_style),
        Spacer(1, 1.5),
        Paragraph(f"<b>Total Bill :</b> Rs. {total_bill_val}", normal_style),
        Spacer(1, 1.5),
        Paragraph(f"<b>Total Paid :</b> Rs. {paid_val}", normal_style),
        Spacer(1, 1.5),
        Paragraph(f"<b>Pending Balance :</b> Rs. {pending_val}", normal_style),
        Spacer(1, 1.5),
        Paragraph("<b>Accepted Modes :</b> <font color='#475569'>UPI / NEFT / RTGS</font>", normal_style),
    ]
    
    qr_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'static', 'images', 'upi_qr.jpeg')
    qr_image = RLImage(qr_path, width=54, height=54) if os.path.exists(qr_path) else Spacer(54, 54)
    qr_cell = [
        qr_image,
        Spacer(1, 2),
        Paragraph("Scan to Pay via UPI", ParagraphStyle('QRSub', parent=normal_style, fontSize=6.5, alignment=1, textColor=colors.HexColor('#64748B')))
    ]
    
    pay_table = Table([
        [Paragraph("<b>PAYMENT DETAILS &amp; UPI QR CODE</b>", ParagraphStyle('PSHead', parent=bold_style, fontSize=7.5, textColor=colors.HexColor('#0F172A'))), "", ""],
        [bank_inner_table, payment_summary_cell, qr_cell]
    ], colWidths=[165, 235, printable_width - 400])
    pay_table.setStyle(TableStyle([
        ('SPAN', (0,0), (-1,0)),
        ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#F1F5F9')),
        ('BOX', (0,0), (-1,-1), 0.75, colors.HexColor('#CBD5E1')),
        ('LINEBELOW', (0,0), (-1,0), 0.75, colors.HexColor('#CBD5E1')),
        ('LINEAFTER', (1,1), (1,1), 0.5, colors.HexColor('#CBD5E1')),
        ('ALIGN', (2,1), (2,1), 'CENTER'),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
        ('TOPPADDING', (0,0), (-1,0), 2.5),
        ('BOTTOMPADDING', (0,0), (-1,0), 2.5),
        ('LEFTPADDING', (0,0), (-1,0), 6),
        ('TOPPADDING', (0,1), (-1,-1), 3.5),
        ('BOTTOMPADDING', (0,1), (-1,-1), 3.5),
        ('LEFTPADDING', (0,1), (-1,-1), 6),
        ('RIGHTPADDING', (0,1), (-1,-1), 6),
        ('BACKGROUND', (0,1), (-1,-1), colors.white),
    ]))
    # 7. Terms & Conditions (Left) & Authorised Signatory (Right) - Exactly matching preview side-by-side cards
    terms_cell = [
        Paragraph("<b>Terms &amp; Conditions:</b>", ParagraphStyle('TermsTitle', parent=bold_style, fontSize=7.5, leading=9, textColor=colors.HexColor('#0F172A'))),
        Spacer(1, 2),
        Paragraph("1. Cheque / NEFT / UPI to be drawn in favour of <b>SAISHA LOGISTICS</b>.<br/>2. Interest @ 18% p.a. will be charged if payment is not cleared within due date.<br/>3. Subject to Navi Mumbai jurisdiction.", 
                  ParagraphStyle('TermsText', parent=normal_style, fontSize=6.8, leading=8.5, textColor=colors.HexColor('#334155')))
    ]
    
    signatory_inner_table = Table([
        [Paragraph("<b>For SAISHA LOGISTICS</b>", ParagraphStyle('SignTitle', parent=bold_style, fontSize=8, alignment=1, textColor=colors.HexColor('#0F172A')))],
        [Spacer(1, 18)],
        [Paragraph("<b>Authorised Signatory</b>", ParagraphStyle('SignAuth', parent=bold_style, fontSize=7.5, alignment=1, textColor=colors.HexColor('#0F172A')))]
    ], colWidths=[125])
    signatory_inner_table.setStyle(TableStyle([
        ('LINEABOVE', (0,2), (0,2), 0.75, colors.HexColor('#94A3B8')),
        ('TOPPADDING', (0,0), (-1,-1), 0),
        ('BOTTOMPADDING', (0,0), (-1,-1), 0),
        ('LEFTPADDING', (0,0), (-1,-1), 0),
        ('RIGHTPADDING', (0,0), (-1,-1), 0),
        ('ALIGN', (0,0), (-1,-1), 'CENTER'),
    ]))
    
    bottom_split_table = Table([
        [terms_cell, "", signatory_inner_table]
    ], colWidths=[365, 8, printable_width - 373])
    bottom_split_table.setStyle(TableStyle([
        ('BOX', (0,0), (0,0), 0.75, colors.HexColor('#CBD5E1')),
        ('BOX', (2,0), (2,0), 0.75, colors.HexColor('#CBD5E1')),
        ('BACKGROUND', (0,0), (0,0), colors.white),
        ('BACKGROUND', (2,0), (2,0), colors.white),
        ('TOPPADDING', (0,0), (-1,-1), 4),
        ('BOTTOMPADDING', (0,0), (-1,-1), 4),
        ('LEFTPADDING', (0,0), (0,0), 6),
        ('RIGHTPADDING', (0,0), (0,0), 6),
        ('LEFTPADDING', (2,0), (2,0), 4),
        ('RIGHTPADDING', (2,0), (2,0), 4),
        ('VALIGN', (0,0), (-1,-1), 'TOP'),
        ('ALIGN', (2,0), (2,0), 'CENTER'),
    ]))

    # Build bottom section
    bottom_story = [
        pay_table,
        Spacer(1, 4),
        bottom_split_table
    ]
    
    # Calculate available vertical space and add dynamic push spacer to pin bottom section to the bottom of the page
    printable_height = 841.8898 - (top_m + bottom_m)
    top_h = sum(f.wrap(printable_width, printable_height)[1] for f in top_story)
    bottom_h = sum(f.wrap(printable_width, printable_height)[1] for f in bottom_story)
    remaining_space = printable_height - (top_h + bottom_h)
    push_spacer_height = max(12, remaining_space - 24)
    
    story = top_story + [Spacer(1, push_spacer_height)] + bottom_story
    
    # Build document with custom bottom red banner on canvas
    doc.build(story, onFirstPage=draw_a4_page_decorations)
    
    if output_path is None:
        buffer.seek(0)
        return buffer
    return output_path
