"""
Database Connection & Schema Initializer
Run this script whenever you update your DATABASE_URL in .env to test the connection
and create all tables in your Supabase PostgreSQL database.
"""
import os
import sys
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

from app import create_app, seed_database
from models import db, User, Client, Invoice, Payment

def test_and_init():
    app = create_app()
    with app.app_context():
        db_uri = app.config['SQLALCHEMY_DATABASE_URI']
        is_supabase = 'supabase' in db_uri.lower() or 'postgres' in db_uri.lower()
        
        print("\n==========================================")
        print("SAISHA LOGISTICS - DATABASE INITIALIZATION")
        print("==========================================")
        
        if is_supabase:
            # Mask password in output for security
            masked_uri = db_uri
            if '@' in db_uri and ':' in db_uri.split('@')[0]:
                prefix = db_uri.split('@')[0]
                user_part = prefix.split('://')[1].split(':')[0]
                host_part = db_uri.split('@')[1]
                masked_uri = f"postgresql://{user_part}:****@{host_part}"
            print(f"Target Database: SUPABASE (PostgreSQL)")
            print(f"Connection URI : {masked_uri}")
        else:
            print(f"Target Database: Local SQLite")
            print(f"Path           : {db_uri}")
            
        print("\nTesting connection and creating schema...")
        try:
            # Create all tables in Supabase / SQLite
            seed_database(app)
            
            # Verify tables
            user_count = User.query.count()
            client_count = Client.query.count()
            invoice_count = Invoice.query.count()
            payment_count = Payment.query.count()
            
            print("\n[SUCCESS] Connection established and schema verified!")
            print(f"- Users registered   : {user_count} (Default: admin / admin123)")
            print(f"- Clients registered : {client_count}")
            print(f"- Invoices created   : {invoice_count}")
            print(f"- Payments recorded  : {payment_count}")
            print("\nYou can now start the application with: python app.py")
            print("==========================================\n")
            return True
        except Exception as e:
            print(f"\n[ERROR] Connection failed: {e}")
            print("\nTroubleshooting tips for Supabase:")
            print("1. Verify your database password in .env (replace [YOUR-PASSWORD]).")
            print("2. In Supabase Dashboard -> Project Settings -> Database, make sure your project is not paused.")
            print("3. Try using the Connection Pooler URI (port 5432 or 6543) if direct connection (port 5432) has firewall restrictions.")
            print("==========================================\n")
            return False

if __name__ == '__main__':
    test_and_init()
